/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;


import java.util.ArrayList;
import java.util.List;


public class GiaoVienDAO {
    List<GiaoVien> ls= new ArrayList<>();
    public int add(GiaoVien gv){
        ls.add(gv);
        return 1;
    }
    public List<GiaoVien> getALLGiaoVien(){
         return ls;
    }
    public int delGiaoVienByID(String ma){
        for(GiaoVien gv: ls){
            if (gv.getMaGV().equalsIgnoreCase(ma)){
                ls.remove(gv);
                return 1;
            }
            
        }
        return -1;
    }
    public GiaoVien getGiaoVienByID(String id){
         for(GiaoVien gv: ls){
             if (gv.getMaGV().equalsIgnoreCase(id)){
                return gv;
            }
             
         } 
         return null;
    }
    public int updateGiaoVienByID(GiaoVien gvNew){
        for(GiaoVien gv: ls){
            if(gv.getMaGV().equalsIgnoreCase(gv.getMaGV())){
                gv.setNgaysinh(gv.getNgaysinh());
                gv.setNgonNgu(gv.getNgonNgu());
                gv.setSdt(gv.getSdt());
                gv.setTenGV(gv.getTenGV());
            return 1;
            }
        }
        return -1;
    }
    
}
    
