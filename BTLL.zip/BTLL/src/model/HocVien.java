/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.Date;

/**
 *
 * @author admin
 */
public class HocVien {
    private String maHV;
    private String tenHV;
    private Date ngaysinh;
    private String time;
    private String lop;
    private String Sdt;
    private String taiLieu;
    private String goiHoc;
    public HocVien() {
        // Constructor mặc định
    }
      public HocVien(String maHV, String tenHV) {
        this.maHV = maHV;
        this.tenHV = tenHV;
    }

    public HocVien(String maHV, String tenHV, Date ngaysinh, String time, String lop, String Sdt, String taiLieu, String goiHoc) {
        this.maHV = maHV;
        this.tenHV = tenHV;
        this.ngaysinh = ngaysinh;
        this.time = time;
        this.lop = lop;
        this.Sdt = Sdt;
        this.taiLieu = taiLieu;
        this.goiHoc = goiHoc;
    }

    public String getMaHV() {
        return maHV;
    }

    public void setMaHV(String maHV) {
        this.maHV = maHV;
    }

    public String getTenHV() {
        return tenHV;
    }

    public void setTenHV(String tenHV) {
        this.tenHV = tenHV;
    }

    public Date getNgaysinh() {
        return ngaysinh;
    }

    public void setNgaysinh(Date ngaysinh) {
        this.ngaysinh = ngaysinh;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getLop() {
        return lop;
    }

    public void setLop(String lop) {
        this.lop = lop;
    }

    public String getSdt() {
        return Sdt;
    }

    public void setSdt(String Sdt) {
        this.Sdt = Sdt;
    }

    public String getTaiLieu() {
        return taiLieu;
    }

    public void setTaiLieu(String taiLieu) {
        this.taiLieu = taiLieu;
    }

    public String getGoiHoc() {
        return goiHoc;
    }

    public void setGoiHoc(String goiHoc) {
        this.goiHoc = goiHoc;
    }



    
 
}
