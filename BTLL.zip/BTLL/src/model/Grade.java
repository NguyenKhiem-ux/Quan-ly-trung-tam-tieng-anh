package model;

public class Grade {
    private int id;
    private HocVien hv;
    private double diemGK, diemCK;
    public Grade(){
    
    }
    public Grade(int id, HocVien hv, double diemGK, double diemCK) {
        this.id = id;
        this.hv = hv;
        this.diemGK = diemGK;
        this.diemCK = diemCK;
    }
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public HocVien getHv() {
        return hv;
    }

    public void setHv(HocVien hv) {
        this.hv = hv;
    }

    public double getDiemGK() {
        return diemGK;
    }

    public void setDiemGK(double diemGK) {
        this.diemGK = diemGK;
    }

    public double getDiemCK() {
        return diemCK;
    }

    public void setDiemCK(double diemCK) {
        this.diemCK = diemCK;
    }  
    public double getTBC(){
        return (getDiemCK()*0.3)+(getDiemGK()*0.7);
    }
    public String getXepLoai(){
        String xl ="";
        double tbc = getTBC();
        if (tbc>6){
            xl = "QUA KHóa";
        }else{
            xl = "Trượt";
        }
        return xl;
    }   
}
