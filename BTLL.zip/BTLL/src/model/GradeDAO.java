/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.ArrayList;
import java.util.List;

public class GradeDAO {
    List<Grade> ls = new ArrayList<>();
    public int add(Grade d){
        ls.add(d);
        return 1;
    }
    public List<Grade> getALLGrade(){
        return ls;
    }
    public Grade getOneGradeByMaHV(String mahv){
        for (Grade d : ls){
            if(d.getHv().getMaHV().equalsIgnoreCase(mahv))
                return d;
        }
        return null;
    
    }
    public int updateGrade(Grade dNew){
        for (Grade d: ls) {
            if(d.getHv().getMaHV().equalsIgnoreCase(dNew.getHv().getMaHV())){
            d.setDiemGK(dNew.getDiemGK());
            d.setDiemCK(dNew.getDiemCK());
            return 1;
            }
        }
        return -1;
    }
    public int delGrade(String mahv){
        Grade d = getOneGradeByMaHV(mahv);
        if (d!=null){
            ls.remove(d);
            return 1;
            
        }
        return -1;
    }
    public Grade getAtPosition(int pos){
        return ls.get(pos);
    }
}
