/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;
import java.util.Date;

/**
 *
 * @author admin
 */
public class GiaoVien {
    private String maGV;
    private String tenGV;
    private Date ngaysinh;
    private String NgonNgu;
    private String Sdt;
   public GiaoVien() {
        // Constructor mặc định
    }  

    public GiaoVien(String maGV, String tenGV, Date ngaysinh, String NgonNgu, String Sdt) {
        this.maGV = maGV;
        this.tenGV = tenGV;
        this.ngaysinh = ngaysinh;
        this.NgonNgu = NgonNgu;
        this.Sdt = Sdt;
    }

    public String getMaGV() {
        return maGV;
    }

    public void setMaGV(String maGV) {
        this.maGV = maGV;
    }

    public String getTenGV() {
        return tenGV;
    }

    public void setTenGV(String tenGV) {
        this.tenGV = tenGV;
    }

    public Date getNgaysinh() {
        return ngaysinh;
    }

    public void setNgaysinh(Date ngaysinh) {
        this.ngaysinh = ngaysinh;
    }

    public String getNgonNgu() {
        return NgonNgu;
    }

    public void setNgonNgu(String NgonNgu) {
        this.NgonNgu = NgonNgu;
    }

    public String getSdt() {
        return Sdt;
    }

    public void setSdt(String Sdt) {
        this.Sdt = Sdt;
    }
   
}
