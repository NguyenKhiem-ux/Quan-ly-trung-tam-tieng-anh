
package model;

import java.util.ArrayList;
import java.util.List;


public class HocVienDAO {
    public static List<HocVien> ls= new ArrayList<>();
    public int add(HocVien hv){
        ls.add(hv);
        return 1;
    }
    public List<HocVien> getALLHocVien(){
         return ls;
    }
    public int delHocVienByID(String ma){
        for(HocVien hv: ls){
            if (hv.getMaHV().equalsIgnoreCase(ma)){
                ls.remove(hv);
                return 1;
            }
            
        }
        return -1;
    }
    public HocVien getHocVienByID(String id){
         for(HocVien hv: ls){
             if (hv.getMaHV().equalsIgnoreCase(id)){
                return hv;
            }
             
         } 
         return null;
    }
    public int updateHocVienByID(HocVien hvNew){
        for(HocVien hv: ls){
            if(hv.getMaHV().equalsIgnoreCase(hvNew.getMaHV())){
            hv.setGoiHoc(hvNew.getGoiHoc());
            hv.setLop(hvNew.getLop());
            hv.setNgaysinh(hvNew.getNgaysinh());
            hv.setSdt(hvNew.getSdt());
            hv.setTaiLieu(hvNew.getTaiLieu());
            hv.setTenHV(hvNew.getTenHV());
            hv.setTime(hvNew.getTime());
            return 1;
            }
        }
        return -1;
    }
    
}
